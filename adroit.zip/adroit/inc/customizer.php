<?php

function adroit_customize_register( $wp_customize ) {
    $wp_customize->get_setting( 'blogname' )->transport         = 'refresh';
    $wp_customize->get_setting( 'blogdescription' )->transport  = 'refresh';
    $wp_customize->get_setting( 'header_textcolor' )->transport = 'refresh';
    
    // IMAGES & HEADER TEXT FOR SLIDER
    
    $wp_customize->add_setting(
        'slider_image_1',
        array(
            'default' => get_template_directory_uri() . '/images/1.jpg',
            'sanitize_callback' => 'esc_url_raw',
        )
    );
    
    $wp_customize->add_setting(
        'slider_image_2',
        array(
            'default' => get_template_directory_uri() . '/images/2.jpg',
            'sanitize_callback' => 'esc_url_raw',
        )
    );
    
    $wp_customize->add_setting(
        'slider_image_3',
        array(
            'default' => get_template_directory_uri() . '/images/3.jpg',
            'sanitize_callback' => 'esc_url_raw',
        )
    );
    
    $wp_customize->add_setting(
        'slider_heading_1',
        array(
            'default' => 'Grow your business.',
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    
    $wp_customize->add_setting(
        'slider_heading_2',
        array(
            'default' => 'Reach the world.',
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    
    $wp_customize->add_setting(
        'slider_heading_3',
        array(
            'default' => 'Your journey begins today!',
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    
    $wp_customize->add_section('adroit_slider', array(
        'title' => __('Image Slider', 'adroit'),
        'priority' => 30,
    ));
    
    /* SLIDER CONTROLS */
  
    $wp_customize->add_control(
        new WP_Customize_Image_Control(
            $wp_customize,
            'slider_image_1',
            array(
               'label'          => __( 'First image', 'adroit' ),
               'type'           => 'image',
               'section'        => 'adroit_slider',
               'settings'       => 'slider_image_1',
               'priority'       => 10,
            )
        )
    ); 
    
    $wp_customize->add_control(
        'slider_heading_1', 
        array(
            'label'         => __( 'Heading 1', 'adroit' ),
            'type'          => 'text',
            'section'       => 'adroit_slider',
            'settings'      => 'slider_heading_1',
            'priority'      => 20,
        ) 
    ); 
  
    $wp_customize->add_control(
        new WP_Customize_Image_Control(
            $wp_customize,
            'slider_image_2',
            array(
               'label'          => __( 'Second image', 'adroit' ),
               'type'           => 'image',
               'section'        => 'adroit_slider',
               'settings'       => 'slider_image_2',
               'priority'       => 30,
            )
        )
    ); 
    
    $wp_customize->add_control(
        'slider_heading_2', 
        array(
            'label'         => __( 'Heading 2', 'adroit' ),
            'type'          => 'text',
            'section'       => 'adroit_slider',
            'settings'      => 'slider_heading_2',
            'priority'      => 40,
        ) 
    ); 
  
    $wp_customize->add_control(
        new WP_Customize_Image_Control(
            $wp_customize,
            'slider_image_3',
            array(
               'label'          => __( 'Third Slider Image', 'adroit' ),
               'type'           => 'image',
               'section'        => 'adroit_slider',
               'settings'       => 'slider_image_3',
               'priority'       => 50,
            )
        )
    ); 
    
    $wp_customize->add_control(
        'slider_heading_3', 
        array(
            'label'         => __( 'Heading 3', 'adroit' ),
            'type'          => 'text',
            'section'       => 'adroit_slider',
            'settings'      => 'slider_heading_3',
            'priority'      => 60,
        ) 
    ); 
    /* Customize contact information */
    
    // Settings
    
    $wp_customize->add_setting(
        'adroit_info_display',    
        array(
            'default' => '1',
            'sanitize_callback' => 'sanitize_text_field',
        )
    ); 
    
    $wp_customize->add_setting(
        'adroit_contact_address',    
        array(
            'defualt' => '550 Theme Park Road, Wordpresston, WP 17550',
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    
    $wp_customize->add_setting(
        'adroit_contact_tel',
        array(
            'default' => '550 505 5005',
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    
    $wp_customize->add_setting(
        'adroit_contact_email',
        array(
            'default' => 'me@mywebsite.com',
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    
    // Section
    
    $wp_customize->add_section('adroit_contact_info', array(
        'title' => __('Contact Info', 'adroit'),
        'priority' => 50,
    ));
    
    // Controls
    
    $wp_customize->add_control('adroit_info_display', array(
        'label' => __('Display contact information', 'adroit'),
        'type'          => 'checkbox',
        'section'       => 'adroit_contact_info',
        'settings'      => 'adroit_info_display',
        'priority'      => 10,  
    )); 
    
    $wp_customize->add_control('adroit_contact_address', array(
        'label' => __('Address', 'adroit'),
        'type'          => 'text',
        'section'       => 'adroit_contact_info',
        'settings'      => 'adroit_contact_address',
        'priority'      => 20,  
    ));
    
    $wp_customize->add_control('adroit_contact_tel', array(
        'label' => __('Telephone', 'adroit'),
        'type'          => 'text',
        'section'       => 'adroit_contact_info',
        'settings'      => 'adroit_contact_tel',
        'priority'      => 30,  
    ));
    
    $wp_customize->add_control('adroit_contact_email', array(
        'label' => __('Email', 'adroit'),
        'type'          => 'text',
        'section'       => 'adroit_contact_info',
        'settings'      => 'adroit_contact_email',
        'priority'      => 40,  
    ));
}

add_action('customize_register', 'adroit_customize_register'); 