<?php

if ( ! function_exists( 'ft_contact_info' )) :
    function adroit_contact_info() { ?>
        <?php if ( get_theme_mod( 'adroit_info_display', 1 ) == '1' ) { ?>
        <div class="info-section"> 
            <ul>
                <?php if ( get_theme_mod( 'adroit_contact_address', '550 Theme Park Road, Wordpresston, WP 17550' )) {
                    echo '<li id="adroit_address">' . sanitize_text_field( get_theme_mod( 'adroit_contact_address', '550 Theme Park Road, Wordpresston, WP 17550' )) . '</li>';
                } ?>
                
                <?php if ( get_theme_mod( 'adroit_contact_tel','550 505 5005' )) {
                    echo '<li id="adroit_tel">' . sanitize_text_field( get_theme_mod( 'adroit_contact_tel', '550 505 5005' )) . '</li>';
                } ?>
                
                <?php if ( get_theme_mod( 'adroit_contact_email', 'me@mywebsite.com' )) {
                    echo '<li id="adroit_email">' . sanitize_text_field( get_theme_mod( 'adroit_contact_email', 'me@mywebsite.com' )) . '</li>';
                } ?>
            </ul>
        </div>
    <?php 
    }
}
endif;