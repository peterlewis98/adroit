<?php

//Slider template
if ( ! function_exists( 'ft_slider_template' ) ) :
    function ft_slider_template() { ?>

<div class="slider">
        <div class="container">
            
            <div class="slide active-slide">
                <?php
                if ( get_theme_mod('slider_image_1', get_template_directory_uri() . '/images/1.png') ) {
                    echo '<img src="' . esc_url(get_theme_mod('slider_image_1', get_template_directory_uri() . '/images/1.jpg')) . '"></img>';
                } ?> 
                
                <?php
                if ( get_theme_mod('slider_heading_1', 'Grow your business.') ) {
                    echo '<span class="heading">' . get_theme_mod('slider_heading_1', 'Grow your business.') . '</span>';
                } ?>
            </div>

            <div class="slide">
                <?php
                if ( get_theme_mod('slider_image_2', get_template_directory_uri() . '/images/1.png') ) {
                    echo '<img src="' . esc_url(get_theme_mod('slider_image_2', get_template_directory_uri() . '/images/2.jpg')) . '"></img>';
                } ?> 
                
                <?php
                if ( get_theme_mod('slider_heading_2', 'Reach the world.') ) {
                    echo '<span class="heading">' . get_theme_mod('slider_heading_2', 'Reach the world.') . '</span>';
                } ?>
            </div>

            <div class="slide">
                <?php
                if ( get_theme_mod('slider_image_3', get_template_directory_uri() . '/images/3.png') ) {
                    echo '<img src="' . esc_url(get_theme_mod('slider_image_3', get_template_directory_uri() . '/images/3.jpg')) . '"></img>';
                } ?> 
                
                <?php
                if ( get_theme_mod('slider_heading_3', 'Your journey begins today!') ) {
                    echo '<span class="heading">' . get_theme_mod('slider_heading_3', 'Your journey begins today!') . '</span>';
                } ?>
            </div>
        </div>
        <div id="button-previous"></div>
        <div id="button-next"></div>

        <input type="button" value="Sign Up" id="sign-up">

        <div class="dot-container">
            <div class="dot active-dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
        </div>
</div>
    
    <?php
    }
endif;
