( function( $ ) {
    
    /* Nav Menu and Location */
    $('#nav-button').click(function() {
        $('.site-nav').toggleClass('active');
        $('#nav-button').toggleClass('active');

        if ($('.site-nav').hasClass('active')) {

                $('body').animate({
                    right: "250px"
                }, 200);
                $('.site-nav').animate({
                    right: "0px"
                }, 200);
        } else {
                $('body').animate({
                    right: "0px"
                }, 200);
                $('.site-nav').animate({
                    right: "-250px"
                }, 200);
        }
    });
	
	
	/* Slider */

	function nextSlide() {
        var currentSlide = $('.active-slide');
        var nextSlide = currentSlide.next();

        var currentDot = $('.active-dot');
        var nextDot = currentDot.next();

        if(nextSlide.length === 0) {
            nextSlide = $('.slide').first();
            nextDot = $('.dot').first();
        }

        currentSlide.fadeOut(700).removeClass('active-slide');
        nextSlide.fadeIn(700).addClass('active-slide');

        currentDot.removeClass('active-dot');
        nextDot.addClass('active-dot');
	}
	
	var slideTimer = setInterval(function () { nextSlide(); }, 3000);
	
    $('#button-next').click(function() {
		nextSlide();
		clearInterval(slideTimer);
    });

    $('#button-previous').click(function() {
        var currentSlide = $('.active-slide');
        var prevSlide = currentSlide.prev();

        var currentDot = $('.active-dot');
        var prevDot = currentDot.prev();

        if(prevSlide.length === 0) {
            prevSlide = $('.slide').last();
            prevDot = $('.dot').last();
        }

        currentSlide.fadeOut(700).removeClass('active-slide');
        prevSlide.fadeIn(700).addClass('active-slide');

        currentDot.removeClass('active-dot');
        prevDot.addClass('active-dot');
		
		clearInterval(slideTimer);
    });
    
} )( jQuery );