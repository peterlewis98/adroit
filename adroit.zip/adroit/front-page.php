<?php get_header(); ?>

        <?php ft_slider_template(); ?>

        <section class="posts grid-row">

            <?php 

            $recentPosts = new WP_query( array(
                'posts_per_page'        => 3,
                'ignore_sticky_posts'   => true,
            )); 

            if ($recentPosts->have_posts()) :
                while ($recentPosts->have_posts()) :

                $recentPosts->the_post(); ?>

                <article class="col-1-3">
                    <div class="content">
                        <a href="<?php the_permalink(); ?>">
                            <div class="post-thumbnail">
                                <?php the_post_thumbnail(); ?>
                                <div class="title-and-excerpt">
                                    <h3><?php the_title(); ?></h3>

                                    <?php the_excerpt(); ?>
                                    <span class="post-info">Posted <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></span>
                                </div>
                            </div>
                        </a>
                    </div>
                </article>          

                <?php 
                endwhile;

                else : 
                    echo '<p>No content found.</p>'; 
            endif;

            wp_reset_postdata(); ?>

        </section>
<?php get_footer(); ?>