<?php get_header(); ?>
            <article class="grid-row post">
                <div class="content">
                   
                    <?php if (have_posts()) : 
                        while (have_posts()) : the_post(); ?>
                    
                    <?php the_post_thumbnail(); ?>
                    
                    <h3><?php the_title(); ?></h3>
                    <span class="post-info">Posted by 
                    <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a> on <?php the_time('F jS, Y'); ?></span>
                    
                    <?php the_content(); ?>

                    <?php endwhile;
                    endif; ?>
                </div>
            </article>
<?php get_footer(); ?>