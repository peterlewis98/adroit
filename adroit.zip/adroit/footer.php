    </main>
        <footer class="site-footer">
            <?php adroit_contact_info(); ?>
            
            <section class="grid-row footer-widgets">
                <?php dynamic_sidebar('footer-area'); ?>
            </section>
            
            <?php $args = array(
                'theme_location' => 'social',
                'link_before' => '<span class="screen-reader-text">',
                'link_after' => '</span>',
            ); 
            
            wp_nav_menu( $args ); ?> 
            
            <p><?php bloginfo('name'); ?> Copyright &copy; <?php echo date('Y'); ?></p>
       
        </footer>
<?php wp_footer(); ?>  

</body>
</html>