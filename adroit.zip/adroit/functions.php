<?php

if ( ! isset( $content_width ) ) {
    $content_width = 600;
}

// Theme setup

function adroit_setup() {
    
    add_theme_support( 'post-thumbnails' );
    
    register_nav_menus( array(
	'primary' => __( 'Primary Menu',      'adroit' ),
	'social'  => __( 'Social Links Menu', 'adroit' ),
    ) );
    
    add_theme_support( 'html5', array(
	'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
    ) );
}

add_action('after_setup_theme', 'adroit_setup');

// Excerpt length

function adroit_excerpt_length() {
    return 20;
}

add_filter( 'excerpt_length', 'adroit_excerpt_length', 20 );

// Enqueue styles, fonts, and scripts

function adroit_resources() {
    
    wp_enqueue_style( 'adroit-fonts', 'http://fonts.googleapis.com/css?family=Lato:400,300|Titillium+Web:300|Roboto+Condensed:400');
    
    wp_enqueue_style( 'font-awesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css' );
    
    wp_enqueue_style( 'adroit-skel', get_template_directory_uri() . '/css/skel.css');
    
    wp_enqueue_style( 'adroit-style', get_stylesheet_uri());     
    
    wp_enqueue_script( 'adroit-jquery', get_template_directory_uri() . '/js/app.js', array( 'jquery' ), '20160304', true );
    
}

add_action('wp_enqueue_scripts', 'adroit_resources');

// Setup widgets

function adroit_widgets_init() {
    register_sidebar( array(
        'name'          => __('Widget Area', 'adroit'),
	'id'            => 'footer-area',
	'description'   => __( 'Add widgets here to appear in your sidebar.', 'adroit' ),
	'before_widget' => '<section id="%1$s" class="col-1-4 widget %2$s"><div class="content">',
	'after_widget'  => '</div></section>',
	'before_title'  => '<h3 class="widget-title">',
	'after_title'   => '</h3>'
        
    )); 
}

add_action('widgets_init', 'adroit_widgets_init'); 

// Customizer

require get_template_directory() . '/inc/customizer.php'; 

require get_template_directory() . '/inc/slider.php';

require get_template_directory() . '/inc/contact-info.php';